//created by Phot Srisupakporn(Rocky)


const express = require('express');
const request = require("request");
const app = express();

var Default_Email = null;
var CC_TOKEN = null; 
var auth0_token = null;
var auth0_type = null;
var test= null;
var CLIENT_ID = '366338992531-9mjn5u7j3vrn60ug8t8h1650m8eqsak1.apps.googleusercontent.com';

//Set Default HTML page being the index.html redirect to login.html
app.use(express.static('CloudCard_Main'));






//declaration for header&body for geting authentication from the token
 var CC_Token_get = {	method: 'POST',
	  			url: 'https://api.onlinephotosubmission.com/api/login',
	  			headers: 
	  				{ 
	     				'Content-Type': 'application/json' 
	     			},
	 			 body: //admin username and password to use to get token
	   				{	 username: 'lucapstone@liberty.edu',
	    				 password: 'laugh tune since stranger' 
	    			},
	 					 json: true 
	 		};
	
	 //Running local host port 3000
	app.listen(3000, function(body,request){
		console.log ("Running Application...");
	});


	request(CC_Token_get, function (error, response, body)
	 {  	
		  	CC_TOKEN = body.access_token//converting auth_token gain from api into variable

	})



	//get email from textbox
	app.get('/email', function(req, res,body){ 
		var token = req.query.Student_Token;

	 const {OAuth2Client} = require('google-auth-library');
	const client = new OAuth2Client(CLIENT_ID);
	async function verify() {
	  const ticket = await client.verifyIdToken({
	      idToken: token,
	      audience: CLIENT_ID,
	      });
  const payload = ticket.getPayload();
  const userid = payload['sub'];

}
verify().catch(console.error);

  // if (console.error = true){
  // 	res.redirect('/CloudCard/Error_Main.html');
		// }
		// else{
	    var email = req.query.Student_Email; //mytext is the name of your input box

//declaration for header&body for creating user with token gain from API and email from user's input
		var createUser = 
			{ 
			method: 'POST',
			  url: 'https://app.cloudcardtools.com/api/people',
			  qs: //extra parameter
					{ 	sendInvitation: 'false',
					     allowUpdate: 'true',
					     getLoginLink: 'true' //need this to create login link
					 },
			  headers: 
				   { 	'X-Auth-Token': CC_TOKEN,}, //token gain from api
				body: 
					{ "email": email},// email gain from user
			  		json: true   	  //require response being json file
			 };


	   
		    request(createUser, function (error, response, body) //calling to create user
			    {

				var response_string = JSON.stringify (body)		//convert json response to string
			  	var response_status = response_string.includes("already exists") //check for if account already exist error
			  	
			  	

				if (response_status ==true)
					{
						console.log("A person with the email " +email+" already exists")
					}
				else
					{
						 res.redirect(body.links.login)    					 //redirect using login links created by the API
						 console.log ("Successfully Redirect User to URL") 			//confirmation for succesfuly redirecting
					}
				});
	    
	}); 







	 






