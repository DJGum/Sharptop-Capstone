﻿


function Main(function_email){
	
	
	

	var auth_token = get_token()
	
	CreateUser(auth_token,function_email)



}




  function get_token(){
  	
  	var Account = 
  			'{'
			   + '"username":"lucapstone@liberty.edu",'
			   + '"password":"laugh tune since stranger"'
				+'}'
	
	var url = "https://api.onlinephotosubmission.com/api/login"		
	
	var xhr = new XMLHttpRequest();
	xhr.open("POST", url,false);
	xhr.send(Account);


	
	//xhr.setRequestHeader("Content-type", "application/json");
		    	
		    	var response_json = JSON.parse(xhr.response);

				return(response_json.access_token)

	
  }


function CreateUser(token,email){

var url = "https://api.onlinephotosubmission.com/api/people"

var email_json = '{'+email+'}'

var xhr = new XMLHttpRequest();

	//xhr.setRequestHeader("Content-type", "application/json");
	xhr.setRequestHeader("Authorization",token)

	xhr.open("POST", url,false);

	xhr.send(email_json);


	
/*
	var premail = '"email": '+'"'+email+'"'
	
	
	
	var user_email = '{'+premail+'}'
	
	
	
		

	var token_1="'["+ token+"]'"
	
	xhr.setRequestHeader( 'Authorization', token_1);
	//xhr.setRequestHeader("Content-type", "application/json");
	var xhr = new XMLHttpRequest();
	xhr.open("POST", test,false);


	xhr.send(user_email);


	
	//xhr.setRequestHeader("Content-type", "application/json");
		    	
		    	var response_json = JSON.parse(xhr.response);
		    	alert(response_json)

			//	return(response_json.access_token)

*/

	
	
}

		
		

