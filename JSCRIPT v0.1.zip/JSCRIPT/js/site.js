﻿// Write your JavaScript code.

  function receive(){

  var FormData,StudentEmail,StudentName,StudentID,StudentSchool

  		FormData = document.getElementById("Form1");


       StudentEmail = FormData.elements["Email"].value;
       
       alert("EMAIL: "+StudentEmail);
       
      
     
      
  }



