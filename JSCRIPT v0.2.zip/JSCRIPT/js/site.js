﻿// Write your JavaScript code.

  function get_token(){

	

  	//need to grab this from the API 
  	var Account = 
  			'{'
			   + '"username":"lucapstone@liberty.edu",'
			   + '"password":"laugh tune since stranger"'
				+'}'
	
	var url = "https://api.onlinephotosubmission.com/api/login"		
	
	var xhr = new XMLHttpRequest();
	xhr.open("POST", url,false);
	xhr.send(Account);


	
	//xhr.setRequestHeader("Content-type", "application/json");
		    	
		    	var bia = JSON.parse(xhr.response);
				 alert(bia.access_token)
  }


		
		

