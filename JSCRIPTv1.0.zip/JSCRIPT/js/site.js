﻿


function Main(function_email,function_ID){
	//alert(function_ID)
	if (function_email === ''||function_ID === '') {
		alert("Empty Input")

		alert("Invalid Input")
		window.location.href = 'Error_Main.html';

		}else{
		
		var auth_token = get_token()
		CreateUser(auth_token,function_email)	
	}
	

	



}




  function get_token(){
  	
  	
  	//need to grab this from the API 
  	var Account = 
  			'{'
			   + '"username":"lucapstone@liberty.edu",'
			   + '"password":"laugh tune since stranger"'
				+'}'
	
	var url = "https://api.onlinephotosubmission.com/api/login"		
	
	var xhr = new XMLHttpRequest();
	xhr.open("POST", url,false);
	xhr.send(Account);

	//alert(xhr.status)
	//add api status checking here
	
	//xhr.setRequestHeader("Content-type", "application/json");
		    	
		    	var bia = JSON.parse(xhr.response);
				 return (bia.access_token)
	
  }


function CreateUser(token,email){
		

var url = "https://app.cloudcardtools.com/api/people?sendInvitation=false"
var email_json = '{'+ '"email": "'+email+'"'+'}'
var xhr = new XMLHttpRequest();

	
	
	xhr.open("POST", url,false);
	xhr.setRequestHeader("Content-type", "application/json");
	xhr.setRequestHeader('X-Auth-Token', token)
	
	xhr.send(email_json);



}

		
		

