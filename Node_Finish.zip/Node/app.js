//created by Phot Srisupakporn(Rocky)


const express = require('express');
const request = require("request");
const app = express();

var Default_Email = null;
var Main_Token = null; 

//Set Default HTML page being the index.html redirect to login.html
app.use(express.static('CloudCard_Main'));

//declaration for header&body for geting authentication from the token
 var token = {	method: 'POST',
	  			url: 'https://api.onlinephotosubmission.com/api/login',
	  			headers: 
	  				{ 
	     				'Content-Type': 'application/json' 
	     			},
	 			 body: //admin username and password to use to get token
	   				{	 username: 'lucapstone@liberty.edu',
	    				 password: 'laugh tune since stranger' 
	    			},
	 					 json: true 
	 		};
	
	 //Running local host port 3000
	app.listen(3000, function(body,request){
		console.log ("Running Application...");
	});


	request(token, function (error, response, body)
	 {  	
		  	Main_Token = body.access_token//converting auth_token gain from api into variable

	})



	//get email from textbox
	app.get('/email', function(req, res,body){ 
		
	    var email = req.query.Student_Email; //mytext is the name of your input box

//declaration for header&body for creating user with token gain from API and email from user's input
		var createUser = 
			{ 
			method: 'POST',
			  url: 'https://app.cloudcardtools.com/api/people',
			  qs: //extra parameter
					{ 	sendInvitation: 'false',
					     allowUpdate: 'true',
					     getLoginLink: 'true' //need this to create login link
					 },
			  headers: 
				   { 	'X-Auth-Token': Main_Token,}, //token gain from api
				body: 
					{ "email": email},// email gain from user
			  		json: true   	  //require response being json file
			 };


	   
		    request(createUser, function (error, response, body) //calling to create user
			    {

				var response_string = JSON.stringify (body)		//convert json response to string
			  	var response_status = response_string.includes("already exists") //check for if account already exist error
			  	
			  	

				if (response_status ==true)
					{
						console.log("A person with the email " +email+" already exists")
					}
				else
					{
						 res.redirect(body.links.login)    					 //redirect using login links created by the API
						 console.log ("Successfully Redirect User to URL") 			//confirmation for succesfuly redirecting
					}
				});
	    
	}); 







	 






